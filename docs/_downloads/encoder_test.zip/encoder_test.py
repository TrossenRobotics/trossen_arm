import trossen_arm

# Test configuration
# IP address of the Trossen Arm controller
IP_ADDRESS = "192.168.1.2"

# Constants
# Tolerance for comparing gripper positions (in meters)
TOLERANCE = 1e-3

if __name__ == '__main__':
    # Verify that only one arm is powered on
    response = input(
        "Please ensure that only one Trossen Arm is powered on. "
        "Is this correct? (y/n): "
    )
    if response.lower() not in ['y', 'yes']:
        print("Aborting test. Please power off all but one Trossen Arm.")
        exit(1)

    # Verify the IP address
    response = input(
        f"This test will interact with the Trossen Arm at {IP_ADDRESS}. "
        "Is this correct? (y/n): "
    )
    if response.lower() not in ['y', 'yes']:
        print(
            "Aborting test. "
            "Please update the IP_ADDRESS variable at line 5 of the script."
        )
        exit(1)

    # Prompt to power off the controller box
    input("Please power off the controller box and press Enter to continue...")

    # Prompt to open the arm's gripper from closed position by 2~4 cm
    input(
        "Please open the arm's gripper from closed position "
        "by 2~4 cm and press Enter to continue..."
    )

    # Prompt to power on the controller box
    input(
        "Please power on the controller box "
        "and press Enter to continue..."
    )

    # Prompt to wait for the LED on the controller box to turn green
    input(
        "Please wait for the LED on the controller box to turn green "
        "and press Enter to continue..."
    )

    # Prompt to close the arm's gripper completely
    input(
        "Please close the arm's gripper completely "
        "and press Enter to continue..."
    )

    # Read the gripper position
    driver = trossen_arm.TrossenArmDriver()
    driver.configure(
        trossen_arm.Model.wxai_v0,
        trossen_arm.StandardEndEffector.wxai_v0_leader,
        IP_ADDRESS,
        False
    )
    first_gripper_position = driver.get_gripper_position()
    print(
        "First gripper position (powered on when gripper were open):",
        first_gripper_position
    )

    # Clean up the driver
    driver.cleanup()

    # Prompt to power off the controller box
    input(
        "Please power off the controller box "
        "and press Enter to continue..."
    )

    # Prompt to close the arm's gripper completely
    input(
        "Please close the arm's gripper completely "
        "and press Enter to continue..."
    )

    # Prompt to power on the controller box
    input(
        "Please power on the controller box "
        "and press Enter to continue..."
    )

    # Prompt to wait for the LED on the controller box to turn green
    input(
        "Please wait for the LED on the controller box to turn green "
        "and press Enter to continue..."
    )

    # Read the gripper position again
    driver.configure(
        trossen_arm.Model.wxai_v0,
        trossen_arm.StandardEndEffector.wxai_v0_leader,
        IP_ADDRESS,
        False
    )
    second_gripper_position = driver.get_gripper_position()
    print(
        "Second gripper position (powered on when gripper were closed):",
        second_gripper_position
    )

    # Check if the gripper positions are approximately equal
    difference = abs(first_gripper_position - second_gripper_position)
    if difference < TOLERANCE:
        print(
            f"TEST PASSED: Gripper positions differ by {difference} m, "
            f"less than {TOLERANCE} m."
        )
        print("This indicates that the encoder are working as expected.")
    else:
        print(
            f"TEST FAILED: Gripper positions differ by {difference} m, "
            f"more than {TOLERANCE} m."
        )
        print("This indicates that the encoder has hardware issues.")
        print("Please contact us at https://www.trossenrobotics.com/support.")
